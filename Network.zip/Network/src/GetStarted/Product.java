package GetStarted;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Product {
    private String prodcode;
    private String prodname;
    private String proddlvrmethod;
    private String proddeptcode;

    private Product(String prodcode, String prodname, String proddlvrmethod, String proddeptcode) {
        super();
        this.prodcode = prodcode;
        this.prodname = prodname.replace("'", " ");
        this.proddlvrmethod = proddlvrmethod;
        this.proddeptcode = proddeptcode;

    }

    public String getProddlvrmethod() {
        return proddlvrmethod;
    }

    public String getProdcode() {
        return prodcode;
    }

    public String getProdname() {
        return prodname;
    }

    public String getProddeptcode() {
        return proddeptcode;
    }

    private static final String COMMA_DELIMITER = ",";
    private static List<Product> productList = new ArrayList<>();
    private static List<Product> dlvrList = new ArrayList<>();

    public static List<Product> getProductList() {
        return productList;
    }

    public static List<Product> getDlvrList() {
        return dlvrList;
    }

    public static void ProductInputFile(String inputFile){

        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(inputFile));

            String line = "";

            br.readLine();

            while ((line = br.readLine()) != null) {
                String[] productDetails = line.split(COMMA_DELIMITER);

                if (productDetails.length > 0) {
                    Product upc = new Product(productDetails[0], productDetails[3], productDetails[66], productDetails[75]);

                    boolean notfound = true;
                    for (Product d : productList) {
                        if (d.getProddlvrmethod().equalsIgnoreCase(productDetails[66])) {
                            notfound = false;
                            break;
                        }
                    }

                    productList.add(upc);

                    if (notfound) {
                        dlvrList.add(upc);

                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                br.close();
            } catch (IOException ie) {
                System.out.println("Error occurred while closing the BufferedReader");
                ie.printStackTrace();
            }
        }

    }
}