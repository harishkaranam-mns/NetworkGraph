package GetStarted;

import org.apache.commons.lang.StringUtils;
import org.apache.tinkerpop.gremlin.driver.Client;
import org.apache.tinkerpop.gremlin.driver.Result;
import org.apache.tinkerpop.gremlin.driver.ResultSet;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class GremlinClass {

    public static void runquery(Client client, String query) throws ExecutionException, InterruptedException {
        //System.out.println("\nSubmitting this Gremlin query: " + query);

        // Submitting remote query to the server.

        ResultSet results = client.submit(query);

        CompletableFuture<List<Result>> completableFutureResults = results.all();
        List<Result> resultList = completableFutureResults.get();

        //for (Result result : resultList) {
        //    System.out.println("\nQuery result:");
        //    System.out.println(result.toString());
        //}
    }

    public static void createDeliveryMethodVertex(Client client, List<Product> list) throws ExecutionException, InterruptedException {
        int i = 0;
        System.out.println("Creates Delivery Method Vertices from the Product File");
        for (Product d : list) {
            String deliveryMethod = d.getProddlvrmethod();

            String query = "g.V('" + deliveryMethod + "').fold().coalesce(unfold(),g.addV('TransportationMode').property('id','" + deliveryMethod + "'))";
            runquery(client, query);
            i = i + 1;
        }
        System.out.println("No of TransportationMode vertices created " + i);
    }

    public static void createTradeItemVertex(Client client, List<Product> list) throws ExecutionException, InterruptedException {
        System.out.println("Creates TradeItem Vertices from the Product File");
        int i = 0;
        for (Product p : list) {
            String prodCode = p.getProdcode();
            String deptCode = p.getProddeptcode();
            String prodname = p.getProdname();

            String query = "g.V('" + prodCode + "').fold().coalesce(unfold(),g.addV('TradeItem').property('id','" + prodCode + "').property('TradeItemDesc','" + prodname + "').property('TradeItemCategory','" + deptCode + "'))";
            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of TradeItem vertices created " + i);
                Thread.sleep(1000);
            }
        }
        System.out.println("No of TradeItem vertices created " + i);
    }

    public static void createTradeItemDeliveryMethodEdge(Client client, List<Product> list) throws ExecutionException, InterruptedException {
        System.out.println("Creates Product and Delivery Method Relations");
        int i = 0;
        for (Product p : list) {
            String prodCode = p.getProdcode();
            String deliveryMethod = p.getProddlvrmethod();

            String query = "g.V('" + prodCode + "').outE('HAS').inV().has('id','" + deliveryMethod + "').fold().coalesce(unfold(),g.V('" + prodCode + "').addE('HAS').to(g.V('" + deliveryMethod + "')))";
            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of TradeItem-HAS->TransportationMode edges created " + i);
                Thread.sleep(3000);
            }
        }
        System.out.println("No of TradeItem-HAS->TransportationMode edges created " + i);
    }

    public static void createSupplyChainNodeVertex(Client client, List<Location> list) throws ExecutionException, InterruptedException {
        int i = 0;
        System.out.println("Creates Location Vertices from the Location File");
        for (Location l : list) {
            String locationName = l.getLocationName();
            String locationID = l.getLocationID();
            String locationType = l.getLocationType();

            String query = "g.V('" + locationID + "').fold().coalesce(unfold(),g.addV('SupplyChainNode').property('id','" + locationID + "').property('LocationName','" + locationName + "').property('LocationType','" + locationType + "'))";
            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of SupplyChainNode vertices created " + i);
                Thread.sleep(3000);
            }
        }
        System.out.println("No of SupplyChainNode vertices created " + i);
    }

    public  static void createDeliveryMethodStoreEdge(Client client, Collection<StoreDeliveryMethod> list) throws ExecutionException, InterruptedException {
        int i = 0;

        System.out.println("Creates TransportationMode-IS_DELIVERED_TO-SupplyChainNode Edges :: " + list.size());
        for (Iterator o = list.iterator(); o.hasNext(); ) {
            StoreDeliveryMethod sdm = (StoreDeliveryMethod) o.next();
            String store = sdm.getStore();
            String dlvrMethod = sdm.getDeliveryMethod();
            String startdate = sdm.getStorestartdate();
            String enddate = sdm.getStoreenddate();
            List<String> schedule = sdm.getSchedule();

            String query = "g.V('" + dlvrMethod + "').addE('IS_DELIVERED_TO').to(g.V('" + store + "')).property('StartDate','" + startdate + "').property('EndDate','" + enddate + "').property('DeliverySchedule','" + schedule + "')";
            //System.out.println(query);
            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of TransportationMode-IS_DELIVERED_TO->SupplyChainNode Edges created " + i);
                Thread.sleep(3000);
            }
        }
        System.out.println("No of TransportationMode-IS_DELIVERED_TO->SupplyChainNode Edges created " + i);
    }

    public static void createDepotStoreEdge(Client client, Collection<StoreDeliveryMethod> list) throws ExecutionException, InterruptedException {
        int i = 0;
        System.out.println("Creates SupplyChainNode-HAS_ROUTE_TO->SupplyChainNode Edges :: " + list.size());

        for (Iterator o = list.iterator(); o.hasNext(); ) {
            StoreDeliveryMethod sdm = (StoreDeliveryMethod) o.next();
            String store = sdm.getStore();
            String depot = sdm.getDepot();
            String startdate = sdm.getDepotstartdate();
            String enddate = sdm.getDepotenddate();
            List<String> leadtime = sdm.getLeadtime();
            String cycle = sdm.getCycle();

            String query = "g.V('" + depot + "').addE('HAS_ROUTE_TO').to(g.V('" + store + "')).property('DeliveryCycle','" + cycle + "').property('StartDate','" + startdate + "').property('EndDate','" + enddate + "').property('LeadTime','" + leadtime + "')";
            //System.out.println(query);
            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of SupplyChainNode-HAS_ROUTE_TO->SupplyChainNode edges " + i);
                Thread.sleep(3000);
            }
        }
        System.out.println("No of SupplyChainNode-HAS_ROUTE_TO->SupplyChainNode edges " + i);
    }

    public static void createHoldVertexwithEdges(Client client, Collection<StoreDeliveryMethod> list) throws ExecutionException, InterruptedException {
        int i = 0;
        System.out.println("Creates Hold Vertex with edges :: " + list.size());

        for (Iterator o = list.iterator(); o.hasNext(); ) {
            StoreDeliveryMethod sdm = (StoreDeliveryMethod) o.next();
            String depot = sdm.getDepot();
            String deliveryMethod = sdm.getDeliveryMethod();
            String startdate = sdm.getDepotstartdate();
            String enddate = sdm.getDepotenddate();
            List<String> leadtime = sdm.getLeadtime();
            List<String> holdid = new ArrayList<>();
            holdid.add(startdate);
            holdid.add(enddate);

            String query = "g.V('" + holdid + "').fold().coalesce(unfold(),g.addV('DepotHold').property('id','" + holdid + "'))";
            System.out.println(query);

            query = "g.V('" + deliveryMethod + "').addE('HAS_HOLD_OF').to(g.V('" + holdid + "'))";
            System.out.println(query);

            query = "g.V('" + holdid + "').addE('HAS_HOLD_ON').to(g.V('" + depot + "')).property('HoldLeadTime','" + leadtime + "')";
            //System.out.println(query);
            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of SupplyChainNode-HAS_ROUTE_TO->SupplyChainNode edges " + i);
                Thread.sleep(3000);
            }
        }
        System.out.println("No of Hold vertices and edges created " + i);
    }

    public static void createTradeItemSourceEdge(Client client, Collection<NetworkSchedule> list) throws ExecutionException, InterruptedException, IOException {
        int i = 0;
        System.out.println("Creates TradeItem-SOURCED_FROM->SupplyChainNode Edges :: " + list.size());
        System.out.println(Calendar.getInstance().getTime());
        FileWriter writer = new FileWriter("UniqueProductSourceEdges.csv");
        String output;
        for (Iterator o = list.iterator(); o.hasNext(); ) {
            NetworkSchedule ups = (NetworkSchedule) o.next();
            String product = StringUtils.stripStart(ups.getProduct(),"0");
            String source = StringUtils.stripStart(ups.getSource(),"0");
            String startdate = ups.getStartdate();
            String enddate = ups.getEnddate();
            List<String> orderLeadTime = ups.getOrderLeadTime();
            List<String> orderSplit = ups.getOrderSplit();

            output = product + "," + source + "," + startdate + "," + enddate ;
            writer.append(output + "\n");


//            String query = "g.V('" + product + "').outE('IS_SOURCED_FROM').inV().has('id','" + source + "').fold().coalesce(unfold(),g.V('" + product + "').addE('IS_SOURCED_FROM').to(g.V('" + source + "')).property('StartDate','" + startdate + "').property('EndDate','" + enddate + "').property('ProductionLeadTime','" + orderLeadTime + "').property('OrderSplit','" + orderSplit + "'))";
//            //System.out.println(query);
//            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of TradeItem-IS_SOURCED_FROM->SupplyChainNode edges processed" + i);
                Thread.sleep(3000);
            }
        }
        writer.close();
        System.out.println("No of TradeItem-SOURCED_FROM->SupplyChainNode edges created" + i);
        System.out.println(Calendar.getInstance().getTime());
    }

    public static void createProductDestinationEdge(Client client, Collection<NetworkSchedule> list) throws ExecutionException, InterruptedException, IOException {
        int i = 0;
        System.out.println("Creates TradeItem-IS_DELIVERED_TO->SupplyChainNode Edges :: " + list.size());
        System.out.println(Calendar.getInstance().getTime());

        FileWriter writer = new FileWriter("UniqueProductDestinationEdges.csv");
        String output;

        for (Iterator o = list.iterator(); o.hasNext(); ) {
            NetworkSchedule ups = (NetworkSchedule) o.next();
            String destination = StringUtils.stripStart(ups.getDestination(),"0");
            String product = StringUtils.stripStart(ups.getProduct(),"0");
            String startdate = ups.getStartdate();
            String enddate = ups.getEnddate();
            List<String> deliverySchedule = ups.getDeliverySchedule();

            output = product + "," + destination + "," + startdate + "," + enddate;
            writer.append(output + "\n");

//            String query = "g.V('" + product + "').outE('IS_DELIVERED_TO').inV().has('id','" + destination + "').fold().coalesce(unfold(),g.V('" + product + "').addE('IS_DELIVERED_TO').to(g.V().has('id','" + destination + "')).property('StartDate','" + startdate + "').property('EndDate','" + enddate + "').property('DeliverySchedule','" + deliverySchedule + "'))";
//            //System.out.println(query);
//            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of TradeItem-IS_DELIVERED_TO->SupplyChainNode edges processed" + i);
                Thread.sleep(3000);
            }
        }
        writer.close();
        System.out.println("No of TradeItem-IS_DELIVERED_TO->SupplyChainNode edges created" + i);
        System.out.println(Calendar.getInstance().getTime());

    }

    public static void createSourceDestinationEdge(Client client, Collection<NetworkSchedule> list) throws ExecutionException, InterruptedException, IOException {
        int i = 0;
        System.out.println("Creates SupplyChainNode-HAS_ROUTE_TO->SupplyChainNode Edges :: " + list.size());
        System.out.println(Calendar.getInstance().getTime());

        FileWriter writer = new FileWriter("UniqueSourceDestinationEdges.csv");
        String output;

        for (NetworkSchedule ups: list) {
            String source = StringUtils.stripStart(ups.getSource(),"0");
            String destination = StringUtils.stripStart(ups.getDestination(),"0");
            String startdate = ups.getStartdate();
            String enddate = ups.getEnddate();
            List<String> shipmentLeadTime = ups.getShipmentLeadTime();
            String cycle = ups.getCycle();

            output = source + "," + destination  + "," + startdate  + "," + enddate  + "," + shipmentLeadTime.get(0)  + "," + shipmentLeadTime.get(1)  + "," + shipmentLeadTime.get(2)  + "," + shipmentLeadTime.get(3)  + "," + shipmentLeadTime.get(4)  + "," + shipmentLeadTime.get(5)  + "," + shipmentLeadTime.get(6);
            writer.append(output + "\n");
//            String query = "g.V('" + source + "').outE('HAS_ROUTE_TO').inV().has('id','" + destination + "').fold().coalesce(unfold(),g.V('" + source + "').addE('HAS_ROUTE_TO').to(g.V().has('id','" + destination + "')).property('StartDate','" + startdate + "').property('EndDate','" + enddate + "').property('ShipmentLeadTime','" + shipmentLeadTime + "').property('DeliveryCycle','" + cycle + "'))";
//            //System.out.println(query);
//            runquery(client, query);

            i = i + 1;
            if (i % 1000 == 0) {
                System.out.println("No of SupplyChainNode-HAS_ROUTE_TO->SupplyChainNode edges processed" + i);
                Thread.sleep(3000);
            }
        }
        writer.close();
        System.out.println("No of SupplyChainNode-HAS_ROUTE_TO->SupplyChainNode edges created" + i);
        System.out.println(Calendar.getInstance().getTime());
    }

}
