package GetStarted;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class NetworkSchedule {
    private String source;
    private String destination;
    private String product;
    private String startdate;
    private String enddate;
    private List<String> orderLeadTime;
    private List<String> shipmentLeadTime;
    private List<String> deliverySchedule;
    private List<String> orderSplit;
    private String cycle;

    public NetworkSchedule(String source, String destination, String product, String startdate, String enddate, List<String> orderLeadTime, List<String> shipmentLeadTime, List<String> orderSplit, List<String> deliverySchedule, String cycle) {
        this.source = source;
        this.destination = destination;
        this.product = product;
        this.startdate = startdate;
        this.enddate = enddate;
        this.orderLeadTime = orderLeadTime;
        this.shipmentLeadTime = shipmentLeadTime;
        this.deliverySchedule = deliverySchedule;
        this.orderSplit = orderSplit;
        this.cycle = cycle;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getProduct() {
        return product;
    }

    public String getStartdate() {
        return startdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public List<String> getOrderLeadTime() { return orderLeadTime; }

    public List<String> getShipmentLeadTime() {
        return shipmentLeadTime;
    }

    public List<String> getDeliverySchedule() {
        return deliverySchedule;
    }

    public String getCycle() {
        return cycle;
    }

    public List<String> getOrderSplit() { return orderSplit; }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    private static final String COMMA_DELIMITER = ",";

    private static HashMap<String,NetworkSchedule> UniqueProductSourceList = new HashMap<>();
    private static TreeMap<String,NetworkSchedule> UniqueProductDestinationList = new TreeMap<>();
    private static TreeMap<String,NetworkSchedule> UniqueSourceDestinationList = new TreeMap<>();

    public static Collection<NetworkSchedule> getUniqueProductSourceList() {
        TreeMap<String, NetworkSchedule> sortedNS = new TreeMap<>(UniqueProductSourceList);
        return sortedNS.values();
    }

    public static Collection<NetworkSchedule> getUniqueProductDestinationList() {
        TreeMap<String, NetworkSchedule> sortedNS = new TreeMap<>(UniqueProductDestinationList);
        return sortedNS.values();
    }

    public static Collection<NetworkSchedule> getUniqueSourceDestinationList() {
        TreeMap<String, NetworkSchedule> sortedNS = new TreeMap<>(UniqueSourceDestinationList);
        return sortedNS.values();
    }

    public static void NetworkScheduleInputFile(String inputFile) throws ParseException, IOException {

        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(inputFile));

            String line = "";
            br.readLine();
            boolean upslfirsttime = true;
            boolean updlfirsttime = true;
            boolean usdlfirsttime = true;
            String prevProduct = "";
            String prevSource = "";
            String prevDestination = "";
            String prevSDate = "";
            String prevkey = "";
            String key = "";

            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            Calendar cal = Calendar.getInstance();

            while ((line = br.readLine()) != null) {
                String[] nsDetails = line.split(COMMA_DELIMITER);

                if (nsDetails.length > 0) {
                    String product = nsDetails[1];
                    String source = nsDetails[3];
                    String destination = nsDetails[5];
                    String startdate = nsDetails[7];
                    String enddate = "99991231";
                    String cycle = "";
                    List<String> productionLeadTime = new ArrayList<>();
                    List<String> shipmentLeadTime = new ArrayList<>();
                    List<String> deliverySchedule = new ArrayList<>();
                    List<String> orderSplit = new ArrayList<>();

                    for (int i = 0; i < 7; i++) {

                        int j = i * 15;

                        // Identify AM or PM cycle
                        if (nsDetails[j + 8].equalsIgnoreCase("2")) {
                            cycle = "AM";
                            break;
                        } else if (nsDetails[j + 8].equalsIgnoreCase("1")) {
                            cycle = "PM";
                            break;
                        }
                    }

                    for (int i = 0; i < 7; i++) {

                        int j = i * 15;

                        // Get delivery schedules
                        if (nsDetails[j + 8].isEmpty()) {
                            deliverySchedule.add("N");
                        } else {
                            deliverySchedule.add("Y");
                        }

                        // Get production lead times
                        if (nsDetails[j + 10].isEmpty()) {
                            productionLeadTime.add(null);
                        } else {
                            productionLeadTime.add(String.valueOf(Integer.parseInt(nsDetails[j + 10]) - Integer.parseInt(nsDetails[j+12])));
                        }

                        // Get shipment lead times
                        if (nsDetails[j + 12].isEmpty()) {
                            shipmentLeadTime.add(null);
                        } else {
                            shipmentLeadTime.add(nsDetails[j + 12]);
                        }

                        // Get order split
                        if (nsDetails[j+13].isEmpty()) {
                            orderSplit.add(null);
                        } else {
                            orderSplit.add(nsDetails[j+13]);
                        }

                    }

                    NetworkSchedule ns = new NetworkSchedule(source, destination, product, startdate, enddate, productionLeadTime, shipmentLeadTime, orderSplit, deliverySchedule, cycle);
                    //System.out.println(product + ";" + source + ";" + destination + ";" + startdate + ";" + enddate);


                    // Create Unique Product Source List
                    key = product + source;
                    if (!UniqueProductSourceList.containsKey(key)) {
                        UniqueProductSourceList.put(key,ns);
                    }

                    // Create Unique Product Destination List
                    key = product + destination;
                    if (!UniqueProductDestinationList.containsKey(key)) {
                        //System.out.println("     add key ---- :: " + key);
                        UniqueProductDestinationList.put(key,ns);
                    }

                    //Create Unique Source Destination List
                    key = source + destination;
                    if (!UniqueSourceDestinationList.containsKey(key)) {
                        UniqueSourceDestinationList.put(key,ns);
                    }

/*
                    key = product + source + startdate;
                    prevkey = prevProduct + prevSource + prevSDate;

                    if (upslfirsttime) {
                        UniqueProductSourceList.put(key,ns);
                        prevkey = key;
                        upslfirsttime = false;
                    }

                    NetworkSchedule prevns = UniqueProductSourceList.get(prevkey);
                    //System.out.println(product + source + startdate + enddate + " -- " + prevns.getProduct() + prevns.getSource() + prevns.getStartdate() + prevns.getEnddate());
                    if (prevns.getProduct().compareTo(product) == 0 && prevns.getSource().compareTo(source) == 0) {

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                        Date currStartDate = sdf.parse(startdate);
                        Date prevStartDate = sdf.parse(prevns.getStartdate());
                        Date prevEndDate = sdf.parse(prevns.getEnddate());

                        if (prevStartDate.compareTo(currStartDate) == 0) {
                            // DO NOTHING
                        } else if (prevEndDate.compareTo(currStartDate) >= 0 && currStartDate.compareTo(prevStartDate) >= 0) {

                            Calendar cal = Calendar.getInstance();
                            cal.setTime(currStartDate);
                            cal.add(Calendar.DATE, -1);
                            prevns.setEnddate(sdf.format(cal.getTime()));
                      //      System.out.println(prevEndDate);
                        }
                    }
                    UniqueProductSourceList.put(key,ns);

                    // Create Unique Product Destination StartDate list
                    key = product + destination + startdate;
                    prevkey = prevProduct + prevDestination + prevSDate;

                    if (updlfirsttime) {
                        UniqueProductDestinationList.put(key,ns);
                        prevkey = key;
                        updlfirsttime = false;
                    }

                    prevns = UniqueProductDestinationList.get(prevkey);
                    //System.out.println(product + destination + startdate + enddate + " -- " + prevns.getProduct() + prevns.getDestination() + prevns.getStartdate() + prevns.getEnddate());
                    if (prevns.getProduct().compareTo(product) == 0 && prevns.getDestination().compareTo(destination) == 0) {

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                        Date currStartDate = sdf.parse(startdate);
                        Date prevStartDate = sdf.parse(prevns.getStartdate());
                        Date prevEndDate = sdf.parse(prevns.getEnddate());

                        if (prevStartDate.compareTo(currStartDate) == 0) {
                            // DO NOTHING
                        } else if (prevEndDate.compareTo(currStartDate) >= 0 && currStartDate.compareTo(prevStartDate) >= 0) {

                            Calendar cal = Calendar.getInstance();
                            cal.setTime(currStartDate);
                            cal.add(Calendar.DATE, -1);
                            prevns.setEnddate(sdf.format(cal.getTime()));
                            //      System.out.println(prevEndDate);
                        }
                    }
                    UniqueProductDestinationList.put(key,ns);

                    // Create Unique Source Destination StartDate list
                    key = source + destination + startdate;
                    prevkey = prevSource + prevDestination + prevSDate;

                    if (usdlfirsttime) {
                        UniqueSourceDestinationList.put(key,ns);
                        prevkey = key;
                        usdlfirsttime = false;
                    }

                    prevns = UniqueSourceDestinationList.get(prevkey);
                    //System.out.println(source + destination + startdate + enddate + " -- " + prevns.getSource() + prevns.getDestination() + prevns.getStartdate() + prevns.getEnddate());
                    if (prevns.getSource().compareTo(source) == 0 && prevns.getDestination().compareTo(destination) == 0) {

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                        Date currStartDate = sdf.parse(startdate);
                        Date prevStartDate = sdf.parse(prevns.getStartdate());
                        Date prevEndDate = sdf.parse(prevns.getEnddate());

                        if (prevStartDate.compareTo(currStartDate) == 0) {
                            // DO NOTHING
                        } else if (prevEndDate.compareTo(currStartDate) >= 0 && currStartDate.compareTo(prevStartDate) >= 0) {

                            Calendar cal = Calendar.getInstance();
                            cal.setTime(currStartDate);
                            cal.add(Calendar.DATE, -1);
                            prevns.setEnddate(sdf.format(cal.getTime()));
                            //      System.out.println(prevEndDate);
                        }
                    }
                    UniqueSourceDestinationList.put(key,ns);

                    prevProduct = product;
                    prevSource = source;
                    prevDestination = destination;
                    prevSDate = startdate;
*/

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                br.close();
            } catch (IOException ie) {
                System.out.println("Error occurred while closing the BufferedReader");
                ie.printStackTrace();
            }
        }

    }


}


