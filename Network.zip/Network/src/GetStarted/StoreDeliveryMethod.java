package GetStarted;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class StoreDeliveryMethod {
    private String depot;
    private String store;
    private String deliveryMethod;
    private String cycle;
    private List<String> schedule;
    private String storestartdate;
    private String storeenddate;
    private String depotstartdate;
    private String depotenddate;
    private List<String> leadtime;

    public StoreDeliveryMethod(String depot, String store, String deliveryMethod, String cycle, List<String> schedule, String storestartdate, String storeenddate, String depotstartdate, String depotenddate, List<String> leadtime) {
        this.depot = depot;
        this.store = store;
        this.deliveryMethod = deliveryMethod;
        this.cycle = cycle;
        this.schedule = schedule;
        this.storestartdate = storestartdate;
        this.storeenddate = storeenddate;
        this.depotstartdate = depotstartdate;
        this.depotenddate = depotenddate;
        this.leadtime = leadtime;
    }

    public String getDepot() {
        return depot;
    }

    public String getStore() {
        return store;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public String getCycle() {
        return cycle;
    }

    public List<String> getSchedule() {
        return schedule;
    }

    public String getStorestartdate() {
        return storestartdate;
    }

    public String getStoreenddate() {
        return storeenddate;
    }

    public void setStoreenddate(String storeenddate) {
        this.storeenddate = storeenddate;
    }

    public String getDepotstartdate() {
        return depotstartdate;
    }

    public String getDepotenddate() {
        return depotenddate;
    }

    public void setDepotenddate(String depotenddate) {
        this.depotenddate = depotenddate;
    }

    public List<String> getLeadtime() {
        return leadtime;
    }

    private static final String COMMA_DELIMITER = ",";
    private static TreeMap<String, StoreDeliveryMethod> UniqueDepotStoreList = new TreeMap<>();

    private static TreeMap<String, StoreDeliveryMethod> UniqueStoreDeliveryList = new TreeMap<>();
    private static TreeMap<String, StoreDeliveryMethod> UniqueDepotHoldList = new TreeMap<>();

    public static Collection<StoreDeliveryMethod> getUniqueDepotStoreList() {
        TreeMap<String, StoreDeliveryMethod> sortedSDM = new TreeMap<>(UniqueDepotStoreList);
        return sortedSDM.values();
    }

    public static Collection<StoreDeliveryMethod> getUniqueStoreDeliveryList() {
        TreeMap<String, StoreDeliveryMethod> sortedSDM = new TreeMap<>(UniqueStoreDeliveryList);
        return sortedSDM.values();
    }

    public static Collection<StoreDeliveryMethod> getUniqueDepotHoldList() {
        TreeMap<String, StoreDeliveryMethod> sortedSDM = new TreeMap<>(UniqueDepotHoldList);
        return sortedSDM.values();
    }

    public static void StoreDeliveryMethodInputFile(String inputFile) {

        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(inputFile));
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            Calendar cal = Calendar.getInstance();
            String line;
            String prevdepot = "";
            String prevstore = "";
            String prevDM = "";
            Date prevdepotSD = sdf.parse("19000101");
            Date prevstoreSD = sdf.parse("19000101");
            String key;
            String depotStoreDatekey;
            String deliveryMethodStoreDateKey;
            String holdkey = null;
            boolean firsttime = true;

            while ((line = br.readLine()) != null) {
                String[] sdmDetails = line.split(COMMA_DELIMITER);

                if (sdmDetails.length > 0) {

                    String depot = sdmDetails[1];
                    String store = sdmDetails[2];
                    String deliveryMethod = sdmDetails[4];


                    Date storestartdate = sdf.parse(sdmDetails[3]);
                    Date storeenddate = sdf.parse("99991231");
                    Date depotstartdate = storestartdate;
                    Date depotenddate = storeenddate;
                    String cycle = sdmDetails[7];
                    List<String> schedule = new ArrayList<>();
                    String[] leadtime = new String[7];

                    for (int i = 0; i < 7; i++) {

                        int j = i * 3;

                        if (sdmDetails[j + 7].equalsIgnoreCase("2")) {
                            cycle = "AM";
                            break;
                        } else if (sdmDetails[j + 7].equalsIgnoreCase("1")) {
                            cycle = "PM";
                            break;
                        }
                    }
                    if (cycle.compareTo("AM") == 0) {
                        for (int i = 0; i < 7; i++) {
                            int j = i * 3;
                            if (!sdmDetails[j + 6].isEmpty()) {
                                cal.setTime(storestartdate);
                                cal.add(Calendar.DATE, -Integer.parseInt(sdmDetails[j + 6]));
                                depotstartdate = cal.getTime();
                                break;
                            }
                        }

                        for (int i = 0; i < 7; i++) {
                            int j = i * 3;
                            if (sdmDetails[j + 7].isEmpty()) {
                                schedule.add("N");
                            } else {
                                schedule.add("Y");
                            }

                            if (!sdmDetails[j + 6].isEmpty()) {
                                int k = i - (Integer.valueOf(sdmDetails[j + 6]) % 7);
                                if (k < 0) {
                                    k = k + 7;
                                }
                                leadtime[k] = sdmDetails[j + 6];
                            }
                        }

                        StoreDeliveryMethod sdm = new StoreDeliveryMethod(depot, store, deliveryMethod, cycle, schedule, sdf.format(storestartdate), sdf.format(storeenddate), sdf.format(depotstartdate), sdf.format(depotenddate), Arrays.asList(leadtime));

                        if (firsttime) {
                            firsttime = false;
                        }
//                        System.out.println(depot + ',' + store + ',' + deliveryMethod + ',' + cycle + ',' + sdf.format(storestartdate));
                        if (!(store.compareTo(prevstore) == 0) || !(depot.compareTo(prevdepot) == 0) || !(deliveryMethod.compareTo(prevDM) == 0) || !(storestartdate.compareTo(prevstoreSD) == 0)) {
                            if (store.compareTo(prevstore) == 0) {
                                if ((deliveryMethod.compareTo(prevDM) == 0) && !(depot.compareTo(prevdepot) == 0)) {
                                    // Depot Store Moves
                                    cal.setTime(depotstartdate);
                                    cal.add(Calendar.DATE, -1);
                                    depotenddate = cal.getTime();

                                    key = prevdepot + store + sdf.format(prevdepotSD);
                                    StoreDeliveryMethod prevsdm = UniqueDepotStoreList.get(key);
//                                    System.out.println( " Ckey ----> " + depotStoreDatekey );

                                    prevsdm.setDepotenddate(sdf.format(depotenddate));

                                    depotStoreDatekey = depot + store + sdf.format(depotstartdate);
//                                    System.out.println( " DSDK ----> " + depotStoreDatekey );

                                    UniqueDepotStoreList.put(depotStoreDatekey, sdm);

                                } else if ((depot.compareTo(prevdepot) == 0) && !(deliveryMethod.compareTo(prevDM) == 0)) {
                                    deliveryMethodStoreDateKey = deliveryMethod + store + sdf.format(storestartdate);
//                                    System.out.println( " DMSDK ---> " + deliveryMethodStoreDateKey);
                                    UniqueStoreDeliveryList.put(deliveryMethodStoreDateKey, sdm);

                                } else {
//                                    // Lead Time Changes
//                                    cal.setTime(depotstartdate);
//                                    cal.add(Calendar.DATE, -1);
//                                    depotenddate = cal.getTime();
//
//                                    key = depot + store + deliveryMethod + sdf.format(prevdepotSD);
////                                    System.out.println( " Ckey  ---> " + depotStoreDateKey);
//                                    if (UniqueDepotHoldList.containsKey(key)) {
//                                        StoreDeliveryMethod prevsdm = UniqueDepotHoldList.get(key);
//                                        prevsdm.setDepotenddate(sdf.format(depotenddate));
//                                    }
//
//                                    holdkey = depot + store + deliveryMethod + sdf.format(depotstartdate);
////                                    System.out.println( " DSDK ----> " + depotStoreDateKey);
//                                    UniqueDepotHoldList.put(holdkey, sdm);
                                }

                            } else {
                                depotStoreDatekey = depot + store + sdf.format(depotstartdate);
                                deliveryMethodStoreDateKey = deliveryMethod + store + sdf.format(storestartdate);

//                                System.out.println( " DSDK ----> " + depotStoreDatekey );
//                                System.out.println( " DMSDK ---> " + deliveryMethodStoreDateKey);

                                UniqueDepotStoreList.put(depotStoreDatekey, sdm);
                                UniqueStoreDeliveryList.put(deliveryMethodStoreDateKey, sdm);
                            }
                        }

                        prevdepot = depot;
                        prevstore = store;
                        prevDM = deliveryMethod;
                        prevdepotSD = depotstartdate;
                        prevstoreSD = storestartdate;

                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                br.close();
            } catch (IOException ie) {
                System.out.println("Error occurred while closing the BufferedReader");
                ie.printStackTrace();
            }
        }


    }
}