package GetStarted;

import org.apache.tinkerpop.gremlin.driver.Client;
import org.apache.tinkerpop.gremlin.driver.Cluster;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Collection;
import java.util.concurrent.ExecutionException;

import static GetStarted.GremlinClass.createProductDestinationEdge;
import static GetStarted.GremlinClass.createSourceDestinationEdge;
import static GetStarted.GremlinClass.createTradeItemSourceEdge;

public class Program
{


    public static void main( String[] args ) throws ExecutionException, InterruptedException, IOException, ParseException {
        /**
         * There typically needs to be only one Cluster instance in an application.
         */
        Cluster cluster;

        /**
         * Use the Cluster instance to construct different Client instances (e.g. one for sessionless communication
         * and one or more sessions). A sessionless Client should be thread-safe and typically no more than one is
         * needed unless there is some need to divide connection pools across multiple Client instances. In this case
         * there is just a single sessionless Client instance used for the entire App.
         */
        Client client;

        try {
            // Attempt to create the connection objects

            cluster = Cluster.build(new File("src/remote.yaml")).create();
            client = cluster.connect();

        } catch (FileNotFoundException e) {
            // Handle file errors.
            System.out.println("Couldn't find the configuration file.");
            e.printStackTrace();
            return;
        }

        // Read Input Files and creates list
//        Product.ProductInputFile("src/InputFiles/ProductInputFile.csv");
//        Location.LocationInputFile("src/InputFiles/LocationInputFile.csv");
//        StoreDeliveryMethod.StoreDeliveryMethodInputFile("src/InputFiles/StoreDeliveryMethodInputFile.csv");
        NetworkSchedule.NetworkScheduleInputFile("src/InputFiles/NetworkScheduleInputFile.csv");

//        List<Product> dlvrList = Product.getDlvrList();
//        List<Product> productList = Product.getProductList();
//        List<Location> locationList = Location.getLocationList();
//        Collection<StoreDeliveryMethod> UniqueDepotStoreList = StoreDeliveryMethod.getUniqueDepotStoreList();
//        Collection<StoreDeliveryMethod> UniqueStoreDeliveryList = StoreDeliveryMethod.getUniqueStoreDeliveryList();
          Collection<NetworkSchedule> UniqueProductSourceList = NetworkSchedule.getUniqueProductSourceList();
          Collection<NetworkSchedule> UniqueSourceDestinationList = NetworkSchedule.getUniqueSourceDestinationList();
          Collection<NetworkSchedule> UniqueProductDestinationList = NetworkSchedule.getUniqueProductDestinationList();

//        // Creates DeliveryMethod Vertex
//        createDeliveryMethodVertex(client, dlvrList);
//
//        // Create TradeItem Vertex
//        createTradeItemVertex(client, productList);
//
//        // Creates Product and Delivery Method Relations
//        createTradeItemDeliveryMethodEdge(client, productList);
//
//        // Create SupplyChainNode Vertex
//        createSupplyChainNodeVertex(client, locationList);
//
//        // Create Delivery Method to Store edges with start date, end date and schedule as edge properties
//        createDeliveryMethodStoreEdge(client, UniqueStoreDeliveryList);
//
//        // Create Depot to Store edges with start date, end date and schedule as edge properties
//        createDepotStoreEdge(client, UniqueDepotStoreList);
//
//        // Create product source edges
        createTradeItemSourceEdge(client, UniqueProductSourceList);
//
        // Create product destination edges
        createProductDestinationEdge(client, UniqueProductDestinationList);

        // Create source destination edges
        createSourceDestinationEdge(client, UniqueSourceDestinationList);

        System.out.println("Upload complete!");

        System.exit(0);
   }


}