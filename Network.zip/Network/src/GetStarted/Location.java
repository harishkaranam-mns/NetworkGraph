package GetStarted;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Location {
    private String LocationID;
    private String LocationName;
    private String LocationType;

    private Location(String LocationID, String LocationName, String LocationType) {
        super();
        this.LocationID = LocationID;
        this.LocationName = LocationName.replace("'"," ");
        this.LocationType = LocationType;
    }

    public String getLocationID() {
        return LocationID;
    }

    public String getLocationName() {
        return LocationName;
    }

    public String getLocationType() {
        return LocationType;
    }

    private static final String COMMA_DELIMITER = ",";
    private static List<Location> locationList = new ArrayList<>();

    public static List<Location> getLocationList() {
        return locationList;
    }

    public static void LocationInputFile(String inputFile){

        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(inputFile));

            String line = "";

            while ((line = br.readLine()) != null) {
                String[] locationDetails = line.split(COMMA_DELIMITER);

                if (locationDetails.length > 0) {
                    String locationType = null;
                    switch (locationDetails[3]) {
                        case "V": locationType = "VENDOR";
                                break;
                        case "N": locationType = "NDC";
                            break;
                        case "S": locationType = "STORE";
                            break;
                        case "W": locationType = "RDC";
                            break;
                    }

                    Location loc = new Location(locationDetails[0], locationDetails[1], locationType);

                    locationList.add(loc);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                br.close();
            } catch (IOException ie) {
                System.out.println("Error occurred while closing the BufferedReader");
                ie.printStackTrace();
            }
        }

    }

}
