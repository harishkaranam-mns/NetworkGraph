package GetStarted;

import org.apache.commons.lang3.StringUtils;
import org.apache.tinkerpop.gremlin.driver.Client;
import org.apache.tinkerpop.gremlin.driver.Cluster;
import org.apache.tinkerpop.gremlin.driver.Result;
import org.apache.tinkerpop.gremlin.driver.ResultSet;

import java.io.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;


public class Program {

    static final String COLUMN_SEPARATOR = ",";

    public static void main(String[] args) throws ExecutionException, InterruptedException, IOException {
        long start = System.currentTimeMillis();
        System.out.println("Extract start time in MS." + start );
        /**
         * There typically needs to be only one Cluster instance in an application.
         */
        Cluster cluster;

        /**
         * Use the Cluster instance to construct different Client instances (e.g. one for sessionless communication
         * and one or more sessions). A sessionless Client should be thread-safe and typically no more than one is
         * needed unless there is some need to divide connection pools across multiple Client instances. In this case
         * there is just a single sessionless Client instance used for the entire App.
         */
        Client client;

        try {
            // Attempt to create the connection objects
            cluster = Cluster.build(new File("src/remote.yaml")).create();
            client = cluster.connect();
        } catch (FileNotFoundException e) {
            // Handle file errors.
            System.out.println("Couldn't find the configuration file.");
            e.printStackTrace();
            return;
        }

        StoreDel extract = new StoreDel();
        List<StoreDel> stordel = new ArrayList<>();

        // Get the depot code
        String depotquery = "g.V().has('SupplyChainNodeType','RDC').as('d').select('d').by('id')";

        ResultSet depotresults = client.submit(depotquery);

        CompletableFuture<List<Result>> depotResults = depotresults.all();
        List<Result> depotresultList = depotResults.get();
        //List<List<String>> lines = new ArrayList<>();
        SortedMap<String, String> lines = new TreeMap<>();

        String depot = null;
        for (Result depotresult : depotresultList) {
            depot = (String) depotresult.getObject();

            // After connection is successful, run all the queries against the server.
            String storeDlvrMethodquery = "g.V('" + depot + "').as('d').outE('HAS_ROUTE_TO').as('r1').inV().as('s').inE('IS_DELIVERED_TO').as('r2').outV().haslabel('TransportationMode').as('t').project('store','depot','deliverymethod','leadtime','schedule').by(select('s').by('id')).by(select('d').by('id')).by(select('t').by('id')).by(select('r1').by(valueMap())).by(select('r2').by(valueMap()))";

            ResultSet storeDlvrMethodresults = client.submit(storeDlvrMethodquery);

            CompletableFuture<List<Result>> storeDlvrMethodcompletableFutureResults = storeDlvrMethodresults.all();
            List<Result> storeDlvrMethodresultList = storeDlvrMethodcompletableFutureResults.get();
            System.out.println(" No of records in " + depot + " :: " + storeDlvrMethodresultList.size());
            if (storeDlvrMethodresultList.size() != 0) {

                for (Result storeDlvrMethodresult : storeDlvrMethodresultList) {
                    Map map = (Map) storeDlvrMethodresult.getObject();
                    StoreDel s = new StoreDel();

                    s.setDepot((String) map.get("depot"));
                    s.setStore(StringUtils.leftPad((String) map.get("store"), 4, "0"));
                    s.setDeliveryMethod((String) map.get("deliverymethod"));

                    Map leadtimemap = (Map) map.get("leadtime");
                    s.setIntoStoreDate((String) leadtimemap.get("StartDate"));

                    String[] leadtime = new String[7];

                    leadtime[0] = (String) leadtimemap.get("SUN");
                    leadtime[1] = (String) leadtimemap.get("MON");
                    leadtime[2] = (String) leadtimemap.get("TUE");
                    leadtime[3] = (String) leadtimemap.get("WED");
                    leadtime[4] = (String) leadtimemap.get("THU");
                    leadtime[5] = (String) leadtimemap.get("FRI");
                    leadtime[6] = (String) leadtimemap.get("SAT");
                    s.setLeadtime(leadtime);


                    Map schedulemap = (Map) map.get("schedule");
                    String depotdate = (String) schedulemap.get("StartDate");

                    String[] schedule = new String[7];
                    schedule[0] = (String) schedulemap.get("SUN");
                    schedule[1] = (String) schedulemap.get("MON");
                    schedule[2] = (String) schedulemap.get("TUE");
                    schedule[3] = (String) schedulemap.get("WED");
                    schedule[4] = (String) schedulemap.get("THU");
                    schedule[5] = (String) schedulemap.get("FRI");
                    schedule[6] = (String) schedulemap.get("SAT");

                    s.setSchedule(schedule);

                    String response;
                    response = s.toString();

                    String key = s.getStore() + s.getDeliveryMethod() + s.getIntoStoreDate();

                    lines.put(key, response);

                }

            }
            //System.out.println(lines.size());
            // For each depot, Sleep to 10 milliseconds
            Thread.sleep(10);
        }

        System.out.println("Writing records to the output file...");

        OutputStream outputStream = new FileOutputStream("src/OutputFile.csv");
        writeCsv(lines, outputStream);

        long end = System.currentTimeMillis();
        System.out.println("Extract End time in MS." + end );

        System.out.println("Total time for the extract in MS." + (end-start) );
        System.exit(0);

    }

    private static void writeCsv(Map<String, String> lines, OutputStream outputStream) throws IOException {
        Writer writer = new OutputStreamWriter(outputStream);

        Collection<String> extract = lines.values();
        //System.out.println(extract.size());
        for (Iterator o = extract.iterator(); o.hasNext(); ) {
            writer.write((String) o.next());
            writer.write(System.lineSeparator());
            //System.out.println(o.next());
        }
        writer.close();

    }

}
