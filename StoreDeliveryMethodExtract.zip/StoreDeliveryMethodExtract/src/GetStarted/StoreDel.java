package GetStarted;

public class StoreDel {
    private String Depot;
    private String Store;
    private String DeliveryMethod;
    private String IntoStoreDate;
    private String Rectype;
    private String[] leadtime;
    private String[] schedule;

    public String getDepot() {
        return Depot;
    }

    public void setDepot(String depot) {
        Depot = depot;
    }

    public String getStore() {
        return Store;
    }

    public void setStore(String store) {
        Store = store;
    }

    public String getDeliveryMethod() {
        return DeliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        DeliveryMethod = deliveryMethod;
    }

    public String getIntoStoreDate() {
        return IntoStoreDate;
    }

    public void setIntoStoreDate(String intoStoreDate) {
        IntoStoreDate = intoStoreDate;
    }

    public String getRectype() {
        return Rectype;
    }

    public void setRectype(String rectype) {
        Rectype = rectype;
    }

    public String[] getLeadtime() {
        return leadtime;
    }

    public void setLeadtime(String[] leadtime) {
        this.leadtime = leadtime;
    }

    public String[] getSchedule() {
        return schedule;
    }

    public void setSchedule(String[] schedule) {
        this.schedule = schedule;
    }

    @Override
    public String toString() {
        String response =  "5," + Depot + "," + Store + "," + DeliveryMethod + "," + IntoStoreDate;
        for (int i=0; i<7; i++) {
            if (schedule[i].compareTo("Y") == 0 && leadtime[i] != null) {
                response = response + ",0," + leadtime[i] + ",2";
            }else {
                response = response + ",,,";
            }
        }
        return response;
    }
}
