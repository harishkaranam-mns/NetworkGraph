﻿//------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------

namespace GraphBulkImportSample
{
    using Microsoft.Azure.CosmosDB.BulkExecutor.Graph.Element;
    using Microsoft.Azure.Documents;
    using Microsoft.Azure.Documents.Client;

    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;

    internal sealed class Utils
    {
        /// <summary>
        /// Get the collection if it exists, null if it doesn't.
        /// </summary>
        /// <returns>The requested collection.</returns>
        public static DocumentCollection GetCollectionIfExists(DocumentClient client, string databaseName, string collectionName)
        {
            if (GetDatabaseIfExists(client, databaseName) == null)
            {
                return null;
            }

            return client.CreateDocumentCollectionQuery(UriFactory.CreateDatabaseUri(databaseName))
                .Where(c => c.Id == collectionName).AsEnumerable().FirstOrDefault();
        }

        /// <summary>
        /// Get the database if it exists, null if it doesn't.
        /// </summary>
        /// <returns>The requested database.</returns>
        public static Database GetDatabaseIfExists(DocumentClient client, string databaseName)
        {
            return client.CreateDatabaseQuery().Where(d => d.Id == databaseName).AsEnumerable().FirstOrDefault();
        }

        /// <summary>
        /// Create a partitioned collection.
        /// </summary>
        /// <returns>The created collection.</returns>
        public static async Task<DocumentCollection> CreatePartitionedCollectionAsync(DocumentClient client, string databaseName,
            string collectionName, int collectionThroughput)
        {
            PartitionKeyDefinition partitionKey = new PartitionKeyDefinition
            {
                Paths = new Collection<string> { $"/{ConfigurationManager.AppSettings["CollectionPartitionKey"]}" }
            };
            DocumentCollection collection = new DocumentCollection { Id = collectionName, PartitionKey = partitionKey };

            try
            {
                collection = await client.CreateDocumentCollectionAsync(
                    UriFactory.CreateDatabaseUri(databaseName),
                    collection,
                    new RequestOptions { OfferThroughput = collectionThroughput });
            }
            catch (Exception e)
            {
                throw e;
            }

            return collection;
        }
        private static string getLongId()
        {
            return new string('1', 2000);
        }
    
        private String depot;
        private String store;
        private String deliveryMethod;
        private String cycle;
        private String[] schedule;
        private String storestartdate;
        private String storeenddate;
        private String depotstartdate;
        private String depotenddate;
        private String[] leadtime;

        public Utils(String depot, String store, String deliveryMethod, String cycle, String[] schedule, String storestartdate, String storeenddate, String depotstartdate, String depotenddate, String[] leadtime)

        {
            this.depot = depot;
            this.store = store;
            this.deliveryMethod = deliveryMethod;
            this.cycle = cycle;
            this.schedule = schedule;
            this.storestartdate = storestartdate;
            this.storeenddate = storeenddate;
            this.depotstartdate = depotstartdate;
            this.depotenddate = depotenddate;
            this.leadtime = leadtime;
        }

        public String getDepot()
        {
            return depot;
        }

        public String getStore()
        {
            return store;
        }

        public String getDeliveryMethod()
        {
            return deliveryMethod;
        }

        public String getCycle()
        {
            return cycle;
        }

        public String[] getSchedule()
        {
            return schedule;
        }

        public String getStorestartdate()
        {
            return storestartdate;
        }

        public String getStoreenddate()
        {
            return storeenddate;
        }

        public void setStoreenddate(String storeenddate)
        {
            this.storeenddate = storeenddate;
        }

        public String getDepotstartdate()
        {
            return depotstartdate;
        }

        public String getDepotenddate()
        {
            return depotenddate;
        }

        public void setDepotenddate(String depotenddate)
        {
            this.depotenddate = depotenddate;
        }

        public String[] getLeadtime()
        {
            return leadtime;
        }

        //private SortedDictionary<String, Utils> UniqueDepotStoreList = new SortedDictionary<String, Utils>();
        //private SortedDictionary<String, Utils> UniqueDeliveryMethodStoreList = new SortedDictionary<String, Utils>();

        //public SortedDictionary<String, Utils> getUniqueDepotStoreList()
        //{
        //    return UniqueDepotStoreList;
        //}

        //public void setUniqueDepotStoreList(SortedDictionary<String, Utils> udsl)
        //{
        //    this.UniqueDepotStoreList = udsl;
        //}

        //public SortedDictionary<String, Utils> getUniqueDeliveryMethodStoreList()
        //{
        //    return UniqueDeliveryMethodStoreList;
        //}

        //public void setUniqueDeliveryMethodStoreList(SortedDictionary<String, Utils> udmsl)
        //{
        //    this.UniqueDeliveryMethodStoreList = udmsl;
        //}

        public static IEnumerable<GremlinEdge> GenerateEdges(long count)
        {

            using (StreamReader sr = new StreamReader("Sample.csv"))
            {
                String line;

                String[] day = new String[7];
                day[0] = "SUN";
                day[1] = "MON";
                day[2] = "TUE";
                day[3] = "WED";
                day[4] = "THU";
                day[5] = "FRI";
                day[6] = "SAT";
                Boolean firsttime = true;
                String prevdeliverymethod = "";
                String prevsource = "";
                String prevdestination = "";
                String prevstorestartdate = "19900101";
                String prevstoreenddate = "99991231";
                String prevdepotstartdate = "19900101";
                String prevdepotenddate = "99991231";

                SortedDictionary<String, Utils> UniqueDepotStoreList = new SortedDictionary<String, Utils>();
                SortedDictionary<String, Utils> UniqueDeliveryMethodStoreList = new SortedDictionary<String, Utils>();

                //Processor details record
                while ((line = sr.ReadLine()) != null)
                {
                    string[] sdmrecord = line.Split(',');

                    String deliverymethod = sdmrecord[4];
                    String source = sdmrecord[1];
                    String destination = sdmrecord[2];
                    DateTime date;
                    String storestartdate = sdmrecord[3];
                    String storeenddate = "99991231";
                    String cycle = null;
                    String depotstartdate = storestartdate;
                    String depotenddate = "99991231";
                    String[] deliveryschedule = new String[7];
                    String[] leadtime = new String[7];
                    String key;
                    for (int i = 0; i < 7; i++)
                    {
                        int j = (i * 3) + 7;

                        if (sdmrecord[j] == "2")
                        {
                            cycle = "AM";
                            break;
                        }
                        else if (sdmrecord[j] == "1")
                        {
                            cycle = "PM";
                            break;
                        }
                    }

                    if (cycle == "AM")
                    {
                        for (int i = 0; i < 7; i++)
                        {
                            int j = (i * 3) + 6;
                            if (sdmrecord[j] != "")
                            {
                                date = DateTime.ParseExact(storestartdate, "yyyyMMdd", null);
                                date = date.AddDays(-1);
                                depotstartdate = date.ToString("yyyyMMdd");
                                break;
                            }
                        }

                        for (int i = 0; i < 7; i++)
                        {
                            int j = (i * 3) + 7;
                            if (sdmrecord[j] == "")
                            {
                                deliveryschedule[i] = "N";
                            }
                            else
                            {
                                deliveryschedule[i] = "Y";
                            }

                            j = j - 1;
                            if (sdmrecord[j] != "")
                            {
                                int k = i - (Int32.Parse(sdmrecord[j]) % 7);
                                if (k < 0)
                                {
                                    k = k + 7;
                                }
                                leadtime[k] = sdmrecord[j];
                            }
                        }

                        if (firsttime)
                        {
                            firsttime = false;
                        }

                        Utils sdm = new Utils(source, destination, deliverymethod, cycle, deliveryschedule, storestartdate, storeenddate, depotstartdate, depotenddate, leadtime);

                        
                        if (!(source.CompareTo(prevsource) == 0) | !(destination.CompareTo(prevdestination) == 0) | !(deliverymethod.CompareTo(prevdeliverymethod) == 0) | !(storestartdate.CompareTo(prevstorestartdate) == 0))
                        {
                            if (destination.CompareTo(prevdestination) == 0)
                            {
                                if ((deliverymethod.CompareTo(prevdeliverymethod) == 0) & !(source.CompareTo(prevsource) == 0))
                                {
                                    // Depot Store Moves

                                    date = DateTime.ParseExact(depotstartdate, "yyyyMMdd", null);
                                    date = date.AddDays(-1);
                                    depotenddate = date.ToString("yyyyMMdd");
                                    
                                    key = prevsource + destination + prevdepotstartdate;
                                    
                                    if (UniqueDepotStoreList.TryGetValue(key, out Utils prevsdm))
                                    {
                                        prevsdm.setDepotenddate(depotenddate);

                                    }

                                    key = source + destination + depotstartdate;
                                    if (UniqueDepotStoreList.ContainsKey(key) == false)
                                    {
                                        UniqueDepotStoreList.Add(key, sdm);
                                    }
                                }
                                else if ((source.CompareTo(prevsource) == 0) && !(deliverymethod.CompareTo(prevdeliverymethod) == 0))
                                {
                                    key = deliverymethod + destination + storestartdate;
                                    if (UniqueDeliveryMethodStoreList.ContainsKey(key) == false)
                                    {
                                        UniqueDeliveryMethodStoreList.Add(key, sdm);
                                    }
                                }
                            }
                            else
                            {
                                key = source + destination + depotstartdate;
                                UniqueDepotStoreList.Add(key, sdm);

                                key = deliverymethod + destination + storestartdate;
                                UniqueDeliveryMethodStoreList.Add(key, sdm);

                            }
                        }

                        prevsource = source;
                        prevdestination = destination;
                        prevdeliverymethod = deliverymethod;
                        prevdepotstartdate = depotstartdate;
                        prevdepotenddate = depotenddate;
                        prevstorestartdate = storestartdate;
                        prevstoreenddate = storeenddate;

                    }
                }

                Console.WriteLine("Unqie DeLiveryMethod Stores :: " + UniqueDeliveryMethodStoreList.Count());
                Console.WriteLine("Unqie Depot Stores :: " + UniqueDepotStoreList.Count());

                // Load Depot-HAS_ROUTE_TO->Store edges



                foreach (KeyValuePair<String, Utils> element in UniqueDepotStoreList)
                {
                    Utils sdm = element.Value;
                    String key = element.Key;
                    String depot = sdm.getDepot();
                    String store = sdm.getStore();
                    String startdate = sdm.getDepotstartdate();
                  
                    String enddate = sdm.getDepotenddate();
                    
                    String[] sdmlt = sdm.getLeadtime();

                //    Console.WriteLine(sdm.getDepot() + ',' + sdm.getStore() + ',' + sdm.getDeliveryMethod() + ',' + sdm.getStorestartdate() + ',' + sdm.getStoreenddate() + ',' + sdm.getDepotstartdate() + ',' + sdm.getDepotenddate() + ',' + sdmlt[3]);

                    GremlinEdge e = new GremlinEdge(key, "HAS_ROUTE_TO", depot, store, "SupplyChainNode", "SupplyChainNode", null, null);
                    e.AddProperty("StartDate", startdate);
                    e.AddProperty("EndDate", enddate);
                    String ltime = "[";
                    for (int i = 0; i < 7; i++)
                    {
                        e.AddProperty(day[i], sdmlt[i]);
                        
                    }
                    
                    yield return e;
                }

                // Load DeliveryMethod-IS_DELIVERED_TO->Store edges
                foreach (KeyValuePair<String, Utils> element in UniqueDeliveryMethodStoreList)
                {
                    Utils sdm = element.Value;
                   
                    String deliveryMethod = sdm.getDeliveryMethod();
                    String store = sdm.getStore();
                    String startdate = String.Format(sdm.getStorestartdate(), "yyyyMMdd");
                    String enddate = String.Format(sdm.getStoreenddate(), "yyyyMMdd");
                    String[] sdmds = sdm.getSchedule();
                    String key = deliveryMethod + store + startdate;
                    //Console.WriteLine(sdm.getDepot() + ',' + sdm.getStore() + ',' + sdm.getDeliveryMethod() + ',' + sdm.getStorestartdate() + ',' + sdm.getStoreenddate() + ',' + sdm.getDepotstartdate() + ',' + sdm.getDepotenddate() + ',' + sdmds[3] + ',' + sdmlt[3]);

                    GremlinEdge e = new GremlinEdge(key, "IS_DELIVERED_TO", deliveryMethod, store, "TransportationMode", "SupplyChainNode", null, null);
                    e.AddProperty("StartDate", startdate);
                    e.AddProperty("EndDate", enddate);

                    for (int i = 0; i < 7; i++)
                    {
                        e.AddProperty(day[i], sdmds[i]);
                    }

                    yield return e;
                }

            }


            

        }
    }
}
