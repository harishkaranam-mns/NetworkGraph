﻿//------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------

namespace GraphBulkImportSample
{
    using Microsoft.Azure.CosmosDB.BulkExecutor.Graph.Element;
    using Microsoft.Azure.Documents;
    using Microsoft.Azure.Documents.Client;

    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;

    internal sealed class Utils
    {
        /// <summary>
        /// Get the collection if it exists, null if it doesn't.
        /// </summary>
        /// <returns>The requested collection.</returns>
        public static DocumentCollection GetCollectionIfExists(DocumentClient client, string databaseName, string collectionName)
        {
            if (GetDatabaseIfExists(client, databaseName) == null)
            {
                return null;
            }

            return client.CreateDocumentCollectionQuery(UriFactory.CreateDatabaseUri(databaseName))
                .Where(c => c.Id == collectionName).AsEnumerable().FirstOrDefault();
        }

        /// <summary>
        /// Get the database if it exists, null if it doesn't.
        /// </summary>
        /// <returns>The requested database.</returns>
        public static Database GetDatabaseIfExists(DocumentClient client, string databaseName)
        {
            return client.CreateDatabaseQuery().Where(d => d.Id == databaseName).AsEnumerable().FirstOrDefault();
        }

        /// <summary>
        /// Create a partitioned collection.
        /// </summary>
        /// <returns>The created collection.</returns>
        public static async Task<DocumentCollection> CreatePartitionedCollectionAsync(DocumentClient client, string databaseName,
            string collectionName, int collectionThroughput)
        {
            PartitionKeyDefinition partitionKey = new PartitionKeyDefinition
            {
                Paths = new Collection<string> { $"/{ConfigurationManager.AppSettings["CollectionPartitionKey"]}" }
            };
            DocumentCollection collection = new DocumentCollection { Id = collectionName, PartitionKey = partitionKey };

            try
            {
                collection = await client.CreateDocumentCollectionAsync(
                    UriFactory.CreateDatabaseUri(databaseName),
                    collection,
                    new RequestOptions { OfferThroughput = collectionThroughput });
            }
            catch (Exception e)
            {
                throw e;
            }

            return collection;
        }

        public static IEnumerable<GremlinEdge> GenerateEdges(long count)
        {
            using (StreamReader sr = new StreamReader("NSCONVERTED.csv"))
            {
                String line;
                // Ignore Header record
                line = sr.ReadLine();
                String[] day = new String[7];
                day[0] = "SUN";
                day[1] = "MON";
                day[2] = "TUE";
                day[3] = "WED";
                day[4] = "THU";
                day[5] = "FRI";
                day[6] = "SAT";

                //Processor details record
                while ((line = sr.ReadLine()) != null)
                {
                    string[] productrecord = line.Split(',');
                    String product = productrecord[2].PadLeft(8, '0');
                    String source = productrecord[4];
                    String destination = productrecord[6];
                    String startdate = productrecord[8];
                    String enddate = productrecord[0];                   
                    
                    // Add product-IS_DELIVERED_TO->destination edges
                    GremlinEdge e = new GremlinEdge("D"+product+ destination+startdate, "IS_DELIVERED_TO",product,destination,"TradeItem","SupplyChainNode",null,null);
                    e.AddProperty("StartDate", startdate);
                    e.AddProperty("EndDate", enddate);

                    for (int i = 0; i < 7; i++)
                    {
                        int j = i * 15;
                        if (productrecord[j + 9] == "")
                        {
                            e.AddProperty(day[i], "N");
                        }
                        else
                        {
                            e.AddProperty(day[i], "Y");
                        }
                    }
                    
                    yield return e;

                    // Add product-IS_SOURCED_FROM->source edges
                    e = new GremlinEdge("S"+product + source + startdate, "IS_SOURCED_FROM", product, source, "TradeItem", "SupplyChainNode", null, null);
                    e.AddProperty("StartDate", startdate);
                    e.AddProperty("EndDate", enddate);
                    yield return e;

                    // Add source-HAS_ROUTE_TO->destination edges
                    e = new GremlinEdge(source + destination + startdate, "HAS_ROUTE_TO", source, destination, "SupplyChainNode", "SupplyChainNode", null, null);
                    e.AddProperty("StartDate", startdate);
                    e.AddProperty("EndDate", enddate);
                    for (int i = 0; i < 7; i++)
                    {
                        int j = i * 15 + 13;
                        e.AddProperty(day[i], productrecord[j]);
                        
                    }
                    yield return e;

                }
            }
        }

        

        private static string getLongId()
        {
            return new string('1', 2000);
        }
    }
}
