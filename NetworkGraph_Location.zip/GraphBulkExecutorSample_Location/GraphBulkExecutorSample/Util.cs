﻿//------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------

namespace GraphBulkImportSample
{
    using Microsoft.Azure.CosmosDB.BulkExecutor.Graph.Element;
    using Microsoft.Azure.Documents;
    using Microsoft.Azure.Documents.Client;

    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;

    internal sealed class Utils
    {
        /// <summary>
        /// Get the collection if it exists, null if it doesn't.
        /// </summary>
        /// <returns>The requested collection.</returns>
        public static DocumentCollection GetCollectionIfExists(DocumentClient client, string databaseName, string collectionName)
        {
            if (GetDatabaseIfExists(client, databaseName) == null)
            {
                return null;
            }

            return client.CreateDocumentCollectionQuery(UriFactory.CreateDatabaseUri(databaseName))
                .Where(c => c.Id == collectionName).AsEnumerable().FirstOrDefault();
        }

        /// <summary>
        /// Get the database if it exists, null if it doesn't.
        /// </summary>
        /// <returns>The requested database.</returns>
        public static Database GetDatabaseIfExists(DocumentClient client, string databaseName)
        {
            return client.CreateDatabaseQuery().Where(d => d.Id == databaseName).AsEnumerable().FirstOrDefault();
        }

        /// <summary>
        /// Create a partitioned collection.
        /// </summary>
        /// <returns>The created collection.</returns>
        public static async Task<DocumentCollection> CreatePartitionedCollectionAsync(DocumentClient client, string databaseName,
            string collectionName, int collectionThroughput)
        {
            PartitionKeyDefinition partitionKey = new PartitionKeyDefinition
            {
                Paths = new Collection<string> { $"/{ConfigurationManager.AppSettings["CollectionPartitionKey"]}" }
            };
            DocumentCollection collection = new DocumentCollection { Id = collectionName, PartitionKey = partitionKey };

            try
            {
                collection = await client.CreateDocumentCollectionAsync(
                    UriFactory.CreateDatabaseUri(databaseName),
                    collection,
                    new RequestOptions { OfferThroughput = collectionThroughput });
            }
            catch (Exception e)
            {
                throw e;
            }

            return collection;
        }

        //public static IEnumerable<GremlinEdge> GenerateEdges(long count)
        //{
        //    using (StreamReader sr = new StreamReader("LocationInputFile.csv"))
        //    {
        //        String line;
        //        // Ignore Header record
        //        line = sr.ReadLine();

        //        //Processor details record
        //        while ((line = sr.ReadLine()) != null)
        //        {
        //            string[] productrecord = line.Split(',');
                    
        //            GremlinEdge e = new GremlinEdge(productrecord[0].PadLeft(8, '0')+ productrecord[66], "HAS",productrecord[0].PadLeft(8,'0'),productrecord[66],"TradeItem","TransportationMode",null,null);

        //            //e.AddProperty("duration", i);

        //            yield return e;
        //        }
        //    }
        //}

        public static IEnumerable<GremlinVertex> GenerateVertices(long count)
        {
            // CosmosDB currently doesn't support documents with id length > 1000
            //GremlinVertex vBad = new GremlinVertex(getLongId(), "TradeItem");
            //vBad.AddProperty(ConfigurationManager.AppSettings["CollectionPartitionKey"], 0);
            //yield return vBad;

            using (StreamReader sr = new StreamReader("LocationInputFile.csv"))
            {
                
                String line;

                // Ignore Header record
                line = sr.ReadLine();

                //Processor details record
                while ((line = sr.ReadLine()) != null)
                {
                    string[] locationrecord = line.Split(',');
     
                    GremlinVertex v = new GremlinVertex(locationrecord[0],"SupplyChainNode");
                                        
                    //v.AddProperty(ConfigurationManager.AppSettings["CollectionPartitionKey"], i);
                    //v.AddProperty("name2", i * 2);

                    yield return v;
                    
                }
                
            }
        }

        private static string getLongId()
        {
            return new string('1', 2000);
        }
    }
}
